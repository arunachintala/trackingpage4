
import React from 'react'
import Page6 from '../src/Components/Page6/Page6'
function App() {
    return (
        <div>
            <Page6 />
        </div>
    )
}
export default App;

